function CVEffects() {

}
CVEffects.prototype.renderFrame = function(){};