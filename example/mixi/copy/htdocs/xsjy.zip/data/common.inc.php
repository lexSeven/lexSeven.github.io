<?php
//数据库连接信息
$cfg_dbtype = 'mysql';
$cfg_dbhost = 'localhost';
$cfg_dbname = 'xsjy';
$cfg_dbuser = 'root';
$cfg_dbpwd = 'root';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>