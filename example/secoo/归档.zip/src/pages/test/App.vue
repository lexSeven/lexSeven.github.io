<template>
    <div id="app">
        <div class="test-warp">
            <p>我愛北京天安門</p>
        </div>
        <home></home>
    </div>
</template>

<script>

import api from 'services/index'
import home from './components/home'

export default {
    name: 'App',
    data () {
        return {}
    },
    methods: {
        // 接口请求
        async login () {
            try {
                const data = await api.login({})
                console.log(data)
            } catch (e) {
                alert(e.message)
            }
        }
    },
    computed: {

    },
    created () {

    },
    mounted () {
        this.login()
    },
    components: {
        home
    }
}
</script>

<style lang="scss" scoped>
    @import "~assets/style/variable.scss";
 .test-warp{
     margin: 10px auto;
     background:$background;

     p {
         font-size: 20px;
         line-height: 30px;
     }
 }
</style>
