<template>
    <h1>{{name}}</h1>
</template>

<script>

export default {
    name: 'about',
    data () {
        return {
            name: 'home组件'
        }
    },
    computed: {

    },
    methods: {

    },
    created: function () {

    }
}
</script>

<style scoped lang="scss">
h1 {
    border: 1px solid #ccc;
    border-radius: 5px;

    font-size: 30px;
    line-height: 40px;
}
</style>
