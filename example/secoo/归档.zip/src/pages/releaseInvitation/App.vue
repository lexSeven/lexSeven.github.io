<template>
    <div id="app" class="wrap">
        <div class="progressBox">
            <div class="line">
                <span class="proDom" style="width: 0%;"></span>
            </div>
            <div class="progressNum">0/2</div>
        </div>
        <div class="invitationBanner">
            <i class="icon icon-camera"></i>
            <span class="uploadText">上传一张活动图</span>
        </div>

        <div class="chooseBox">
            <span class="chooseName">活动类型</span>
            <span class="chooseDes">
                想一起做点什么？
                <i class="icon icon-next"></i>
            </span>
        </div>
        <div class="chooseBox">
            <span class="chooseName">活动类型</span>
            <span class="chooseDes">
                想一起做点什么？
                <i class="icon icon-next"></i>
            </span>
        </div>
        <div class="chooseBox">
            <span class="chooseName">活动地点</span>
            <span class="chooseDes">
                选个有趣的地方约起来吧
                <i class="icon icon-next"></i>
            </span>
        </div>
        <div class="chooseBox">
            <span class="chooseName">活动时间</span>
            <span class="chooseDes">
                开始时间
                <i class="icon icon-next"></i>
            </span>
        </div>
        <div class="chooseBox">
            <span class="chooseName"></span>
            <span class="chooseDes">
                结束时间
                <i class="icon icon-next"></i>
            </span>
        </div>
        <div class="timeDes">
            请选择最近15天内的活动时间，注意设置适宜的活动时长哦
        </div>
        <div class="nextBtn">
            <span>下一步</span>
        </div>

        <!--<div class="alertBoxMark">&nbsp;</div>
        <div class="alertInvType">
            <div class="alertTitle">
                <span>请选择活动类型</span>
                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="200px" height="200.00px" viewBox="0 0 1024 1024" version="1.1"><path fill="#333333" d="M810.666667 273.493333L750.506667 213.333333 512 451.84 273.493333 213.333333 213.333333 273.493333 451.84 512 213.333333 750.506667 273.493333 810.666667 512 572.16 750.506667 810.666667 810.666667 750.506667 572.16 512z"/></svg>
            </div>
            <div class="typeCard">
                <div class="item">互动交友</div>
                <div class="item">潮人打卡</div>
                <div class="item">户外运动</div>
                <div class="item">健康生活</div>
                <div class="item">新技能</div>
                <div class="item">手工制作</div>
                <div class="item">饮食文化</div>
                <div class="item">潮人打卡</div>
                <div class="item">户外运动</div>
                <div class="item">黑科技</div>
                <div class="item">游戏竞技</div>
                <div class="item">游戏竞技猜猜猜</div>
            </div>
        </div>-->
    </div>
</template>

<script>

import api from 'services/index'
import home from './components/home'

export default {
    name: 'App',
    data () {
        return {}
    },
    methods: {
        // 接口请求
        async login () {
            try {
                const data = await api.login({})
                console.log(data)
            } catch (e) {
                alert(e.message)
            }
        }
    },
    computed: {

    },
    created () {

    },
    mounted () {
        // this.login()
    },
    components: {
        home
    }
}
</script>

<style lang="scss" scoped>
@import "~assets/style/variable.scss";
@import "~assets/style/style.css";

    @mixin center{
        font-size: 0;
        line-height: 0;
        &:before{
            content: '';
            width: 0;
            height: 100%;
            display: inline-block;
            vertical-align: middle;
        }
    }

    .progressBox{
        width: 670px;
        height: 80px;
        padding: 30px 40px 0;
        display: flex;
        justify-content: space-between;
        align-items: center;

        .line{
            width: 600px;
            height: 4px;
            background: #E1E1E1;

            .proDom{
                height: 100%;
                background: #09D4D2;
                position: relative;
                display: block;

                &:after{
                    content: '';
                    width: 100px;
                    height: 100%;
                    position: absolute;
                    left: 100%;
                    background: linear-gradient(to right,#09D4D2,#E1E1E1);
                }

            }
        }

        .progressNum{
            font:100 24px/31px 'FuturaLT-Light';
            color: #000;
        }

    }

    .invitationBanner{
        margin: 0 auto;
        width: 670px;
        height: 300px;
        background: #F5F5F5;
        margin-bottom: 24px;
        text-align: center;

        .icon{
            display: inline-block;
            padding-top: 89px;
            font-size: 70px;
            opacity: 0.2;
        }
        .uploadText{
            display: inline-block;
            width: 100%;
            font: 100 24px/33px 'PingFangSC-Light';
            padding-top: 20px;
            color: #999999;
        }
    }

    .chooseBox{
        width: 710px;
        height: 120px;
        margin-left: 40px;
        padding-right: 40px;
        border-bottom: 1px solid #E1E1E1;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-sizing: border-box;

        .chooseName{
            font: 34px/48px 'PingFangSC-Medium';
            color: #000;
        }

        .chooseDes{
            font: 100 26px/37px 'PingFangSC-Light';
            color: #666;

            .icon{
                display: inline-block;
                color: #999;
                height: 30px;
                font-size: 20px;
                opacity: 0.6;
            }
        }
    }

    .timeDes{
        font: 24px/33px 'PingFangSC-Light';
        color: #999;
        padding: 20px 40px 0;
    }

    .nextBtn{
        width: 670px;
        height: 90px;
        margin: 50px auto 50px;
        @include center;
        text-align: center;
        background: linear-gradient(40deg,#50A9EE,#30FFC0);
        border-radius: 4px;

        span{
            display: inline-block;
            vertical-align: middle;
            font: 34px/48px 'PingFangSC-Semibold';
            color: #fff;
        }
    }

    .alertBoxMark{
        position: fixed;
        width: 100vw;
        height: 100vh;
        background: rgba(0,0,0,0.6);
        top: 0;
        left: 0;
    }

    .alertInvType{
        position: fixed;
        width: 100vw;
        height: 534px;
        bottom: 0;
        left: 0;
        background: #fff;

        .alertTitle{
            height: 110px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font: 34px/48px 'PingFangSC-Medium';
            color: #1A191E;
            padding-left: 30px;

            svg{
                width: 35px;
                height: 35px;
                padding: 28px;
            }
        }

        .typeCard{
            padding: 12px 30px 0;


            .item{
                height: 70px;
                box-sizing: border-box;
                padding: 0 30px;
                margin: 18px 20px 0 0;
                border: 1px solid #CCCCCC;
                border-radius: 4px;
                font:100 28px/70px 'PingFangSC-Light';
                color: #1A191E;
                float: left;

                &:hover{
                    border-color: #09D4D2;
                    background: #09D4D2;
                    color: #fff;
                }
            }
        }

    }

ssh-keygen -t rsa -C "q213546879@hotmail.com" -b 4096

</style>
