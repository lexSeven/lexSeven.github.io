export default {
    setGroup ({ commit }, item) {
        commit('addGroup', item)
    },
}