/**
 * api接口的统一出口
 */
import { get } from 'common/ajax'
import { getConfig } from 'common/utils'
const { url } = getConfig()
const { ct } = url
export default {
    login: (params) => get(`${ct}/test`, params), // 测试
    inviteDetail: (params) => get(`${ct}/sac-offline-activity-web/api/invitation/detail`, params),
    signUpList: (params) => get(`${ct}/sac-offline-activity-web/api/invitation/recordList`, params)
}
