export const getConfig = () => {
    const env = process.env
    return {
        url: {
            ct: env.VUE_APP_URL_CT
        }
    }
}

export default {}
