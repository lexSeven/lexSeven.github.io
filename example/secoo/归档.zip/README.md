# install dependencies
npm install
# serve with hot reload at localhost:8080
npm run serve
# build for production with minification
npm run build
# serve with hot reload at localhost:8080 and use mock data
npm run mock                                                                                       


